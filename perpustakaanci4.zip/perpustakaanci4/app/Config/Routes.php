<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/','Home::index');

$routes->get('/logout', 'Login::logout');
$routes->get('/admin/dashboard', 'AdminController::index');
$routes->get('/admin/manage-users', 'AdminController::manageUsers');
$routes->get('/admin/manage-books', 'AdminController::manageBooks');
$routes->get('/admin/manage-borrowing', 'AdminController::manageBorrowing');
$routes->get('/peminjaman', 'PeminjamanController::index');
$routes->get('/peminjaman/tambah', 'PeminjamanController::tambah');
$routes->post('/peminjaman/simpan', 'PeminjamanController::simpan');
$routes->get('/petugas/dashboard', 'PetugasController::index');
$routes->get('/petugas/manage-books', 'PetugasController::manageBooks');
$routes->get('/petugas/manage-borrowing', 'PetugasController::dataPeminjaman');
$routes->post('/petugas/save-book', 'PetugasController::saveBook');
$routes->post('/petugas/update-book', 'PetugasController::updateBook');
$routes->get('/petugas/delete-book/(:num)', 'PetugasController::deleteBook/$1');
$routes->get('/petugas/manage-borrowing', 'PetugasController::dataPeminjaman');
$routes->post('/petugas/update-borrow', 'PetugasController::updateBorrow');
$routes->get('/petugas/delete-borrow/(:num)', 'PetugasController::deleteBorrow/$1');
$routes->get('/petugas/return-book/(:num)', 'PetugasController::returnBook/$1');
// Tambahkan di dalam file app/Config/Routes.php
$routes->post('petugas/save-borrow', 'PetugasController::saveBorrow');
$routes->get('petugas/manage-members', 'PetugasController::manageMembers');
$routes->post('petugas/save-member', 'PetugasController::saveMember');
$routes->post('petugas/update-member', 'PetugasController::updateMember');
$routes->get('petugas/delete-member/(:num)', 'PetugasController::deleteMember/$1');



$routes->setAutoRoute(true);