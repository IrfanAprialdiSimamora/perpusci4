<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Peminjaman</title>
</head>
<body>
    <h2>Daftar Peminjaman</h2>

    <?php if (!empty(session()->getFlashdata('success'))) : ?>
        <p style="color:green"><?= session()->getFlashdata('success') ?></p>
    <?php endif; ?>

    <table border="1">
        <tr>
            <th>ID Peminjaman</th>
            <th>ID Anggota</th>
            <th>ID Buku</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Status</th>
        </tr>
        <?php if (!empty($peminjaman)) : ?>
            <?php foreach ($peminjaman as $row) : ?>
                <tr>
                    <td><?= $row['id_peminjaman'] ?></td>
                    <td><?= $row['id_anggota'] ?></td>
                    <td><?= $row['id_buku'] ?></td>
                    <td><?= $row['tanggal_pinjam'] ?></td>
                    <td><?= $row['tanggal_kembali'] ?></td>
                    <td><?= $row['status'] ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="6">Tidak ada data peminjaman</td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>
