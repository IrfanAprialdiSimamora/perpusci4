<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Perpustakaan</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?= base_url('/') ?>">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Peminjaman</a></li>

                <?php if (session()->get('logged_in')): ?>
                    <li class="nav-item"><a class="nav-link">👤 <?= session()->get('username') ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('logout') ?>">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('login') ?>">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


<div class="container text-center mt-5">
    <h1>Selamat Datang di Perpustakaan</h1>
    <p class="lead">Temukan dan pinjam buku dengan mudah.</p>
    <a href="#" class="btn btn-primary">Lihat Koleksi Buku</a>
</div>

<footer class="bg-light text-center py-3 mt-5">
    <p>&copy; 2025 Perpustakaan Digital. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
