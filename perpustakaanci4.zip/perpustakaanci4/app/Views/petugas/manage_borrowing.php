<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <span class="navbar-brand">Perpustakaan</span>
        <a href="<?= base_url('logout') ?>" class="btn btn-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container mt-4">

    <!-- Header -->
    <div class="d-flex justify-content-between mb-3">
        <h3>📖 Kelola Peminjaman</h3>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
            + Tambah
        </button>
    </div>

    <!-- Notifikasi -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <!-- Table -->
    <div class="card shadow">
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="table-primary text-center">
                    <tr>
                        <th>No</th>
                        <th>Buku</th>
                        <th>Anggota</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th width="220">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; foreach($peminjaman as $b): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $b['judul_buku'] ?></td>
                        <td><?= $b['nama_anggota'] ?></td>
                        <td><?= $b['tanggal_pinjam'] ?></td>
                        <td><?= $b['tanggal_kembali'] ?></td>
                        <td>
                            <span class="badge bg-<?= $b['status']=='dipinjam'?'warning':'success' ?>">
                                <?= $b['status'] ?>
                            </span>
                        </td>
                        <td class="text-center">

                            <!-- Edit -->
                            <button class="btn btn-warning btn-sm"
                                data-bs-toggle="modal"
                                data-bs-target="#edit<?= $b['id_peminjaman'] ?>">
                                Edit
                            </button>

                            <!-- Hapus -->
                            <a href="<?= base_url('petugas/delete-borrow/'.$b['id_peminjaman']) ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Hapus data?')">
                               Hapus
                            </a>

                            <!-- Kembalikan -->
                            <?php if($b['status']=='dipinjam'): ?>
                            <a href="<?= base_url('petugas/return-book/'.$b['id_peminjaman']) ?>"
                               class="btn btn-success btn-sm"
                               onclick="return confirm('Kembalikan buku ini?')">
                               Kembalikan
                            </a>
                            <?php endif; ?>

                        </td>
                    </tr>

                    <!-- MODAL EDIT -->
                    <div class="modal fade" id="edit<?= $b['id_peminjaman'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">

                                <form action="<?= base_url('petugas/update-borrow') ?>" method="post">
                                    <input type="hidden" name="id" value="<?= $b['id_peminjaman'] ?>">

                                    <div class="modal-header bg-warning">
                                        <h5>Edit Peminjaman</h5>
                                        <button class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>

                                    <div class="modal-body">

                                        <label>Tanggal Kembali</label>
                                        <input type="date" name="tanggal_kembali"
                                            value="<?= $b['tanggal_kembali'] ?>"
                                            class="form-control">

                                        <label class="mt-2">Status</label>
                                        <select name="status" class="form-control">
                                            <option value="dipinjam" <?= $b['status']=='dipinjam'?'selected':'' ?>>Dipinjam</option>
                                            <option value="dikembalikan" <?= $b['status']=='dikembalikan'?'selected':'' ?>>Dikembalikan</option>
                                        </select>

                                    </div>

                                    <div class="modal-footer">
                                        <button class="btn btn-success">Update</button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- MODAL TAMBAH -->
<div class="modal fade" id="modalTambah">
    <div class="modal-dialog">
        <div class="modal-content">

            <form action="<?= base_url('petugas/save-borrow') ?>" method="post">

                <div class="modal-header bg-primary text-white">
                    <h5>Tambah Peminjaman</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <label>Buku</label>
                    <select name="id_buku" class="form-control mb-2" required>
                        <option value="">Pilih Buku</option>
                        <?php foreach($books as $bk): ?>
                            <option value="<?= $bk['id_buku'] ?>">
                                <?= $bk['judul'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label>Anggota</label>
                    <select name="id_anggota" class="form-control mb-2" required>
                        <option value="">Pilih Anggota</option>
                        <?php foreach($members as $m): ?>
                            <option value="<?= $m['id_anggota'] ?>">
                                <?= $m['nama'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label>Tanggal Pinjam</label>
                    <input type="date" name="tanggal_pinjam" class="form-control mb-2" required>

                    <label>Tanggal Kembali</label>
                    <input type="date" name="tanggal_kembali" class="form-control mb-2" required>

                </div>

                <div class="modal-footer">
                    <button class="btn btn-success">Simpan</button>
                </div>

            </form>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>