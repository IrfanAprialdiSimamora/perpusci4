<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pengembalian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">

    <h3 class="mb-3">📦 Data Pengembalian</h3>

    <table class="table table-bordered table-hover">
        <thead class="table-success text-center">
            <tr>
                <th>No</th>
                <th>Buku</th>
                <th>Anggota</th>
                <th>Tanggal Pengembalian</th>
                <th>Denda</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; foreach($pengembalian as $p): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $p['judul_buku'] ?></td>
                <td><?= $p['nama_anggota'] ?></td>
                <td><?= $p['tanggal_pengembalian'] ?></td>
                <td>Rp <?= number_format($p['denda'],0,',','.') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="<?= base_url('petugas/dashboard') ?>" class="btn btn-secondary">Kembali</a>

</div>

</body>
</html>