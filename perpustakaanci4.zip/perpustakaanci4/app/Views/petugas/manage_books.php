<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Perpustakaan</a>
            <div class="ms-auto">
                <span class="text-white me-3">
                    👤 <?= session()->get('username') ?>
                </span>
                <a href="<?= base_url('logout') ?>" class="btn btn-light btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mt-5">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>📚 Kelola Data Buku</h3>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
                + Tambah Buku
            </button>
        </div>

        <!-- Table -->
        <div class="card shadow">
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <thead class="table-primary text-center">
                        <tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Penulis</th>
                            <th>ISBN</th>
                             <th>Penerbit</th>
                            <th>Tahun Terbit</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($books)): ?>
                            <?php $no = 1; ?>
                            <?php foreach ($books as $book): ?>
                                <tr>
                                    <td class="text-center"><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($book['judul']) ?></td>
                                    <td><?= htmlspecialchars($book['penulis']) ?></td>
                                    <td><?= htmlspecialchars($book['isbn']) ?></td>
                                    <td><?= htmlspecialchars($book['penerbit']) ?></td>
                                    <td><?= htmlspecialchars($book['tahun_terbit']) ?></td>
                                    <td><?= htmlspecialchars($book['jumlah']) ?></td>
                                    <td class="text-center">
                                        <a href="#" class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#modalEdit<?= $book['id_buku'] ?>">
                                            Edit
                                        </a>
                                        <a href="<?= base_url('petugas/delete-book/'.$book['id_buku']) ?>"
                                        class="btn btn-danger btn-sm"
                                        onclick="return confirm('Yakin ingin hapus?')">
                                        Hapus
                                        </a>
                                    </td>
                                </tr>
                                  <!-- Modal Edit -->
<div class="modal fade" id="modalEdit<?= $book['id_buku'] ?>">
    <div class="modal-dialog">
        <div class="modal-content">

            <form action="<?= base_url('petugas/update-book') ?>" method="post">

                <input type="hidden" name="id_buku" value="<?= $book['id_buku'] ?>">

                <div class="modal-header bg-warning">
                    <h5>Edit Buku</h5>
                </div>

                <div class="modal-body">

                    <input type="text" name="isbn" class="form-control mb-2"
                        value="<?= $book['isbn'] ?>" required>

                    <input type="text" name="judul" class="form-control mb-2"
                        value="<?= $book['judul'] ?>" required>

                    <input type="text" name="penulis" class="form-control mb-2"
                        value="<?= $book['penulis'] ?>">

                    <input type="text" name="penerbit" class="form-control mb-2"
                        value="<?= $book['penerbit'] ?>">

                    <input type="number" name="tahun_terbit" class="form-control mb-2"
                        value="<?= $book['tahun_terbit'] ?>">

                    <input type="number" name="jumlah" class="form-control"
                        value="<?= $book['jumlah'] ?>">

                </div>

                <div class="modal-footer">
                    <button class="btn btn-success">Update</button>
                </div>

            </form>

        </div>
    </div>
</div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Tidak ada data buku</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <!-- Modal Tambah Buku -->
                <div class="modal fade" id="modalTambah" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <form action="<?= base_url('petugas/save-book') ?>" method="post">

                                <!-- Header -->
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">Tambah Buku</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <!-- Body -->
                                <div class="modal-body">

                                    <div class="mb-3">
                                        <label>Judul Buku</label>
                                        <input type="text" name="judul" class="form-control" required>
                                    </div>

                                    <div class="mb-3">
                                        <label>Penulis</label>
                                        <input type="text" name="penulis" class="form-control" required>
                                    </div>

                                    <div class="mb-3">
                                        <label>Penerbit</label>
                                        <input type="text" name="penerbit" class="form-control">
                                    </div>


                                    <div class="mb-3">
                                        <label>ISBN</label>
                                        <input type="text" name="isbn" class="form-control" required>
                                    </div>

                                    <div class="mb-3">
                                        <label>Jumlah</label>
                                        <input type="number" name="jumlah" class="form-control" required>
                                    </div>

                                    <div class="mb-3">
                                        <label>Tahun Terbit</label>
                                        <input type="number" name="tahun_terbit" class="form-control" required>
                                    </div>

                                </div>

                                <!-- Footer -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-success"
                                        onclick="this.disabled=true;this.form.submit();">
                                        Simpan
                                    </button>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Back -->
        <div class="mt-3">
            <a href="<?= base_url('petugas/dashboard') ?>" class="btn btn-secondary">
                ← Kembali ke Dashboard
            </a>
        </div>

    </div>

    <!-- Footer -->
    <footer class="text-center mt-5 mb-3 text-muted">
        <small>© <?= date('Y') ?> Perpustakaan Digital</small>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>