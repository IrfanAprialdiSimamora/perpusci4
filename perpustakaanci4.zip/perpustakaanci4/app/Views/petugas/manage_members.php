<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Members | Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="card border-0 shadow-sm p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold text-primary"><i class="fas fa-user-tag me-2"></i>Data Anggota</h3>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                <i class="fas fa-plus me-1"></i> Tambah Anggota
            </button>
        </div>

        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Nama Lengkap</th>
                        <th>Kontak</th>
                        <th>Alamat</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $m): ?>
                    <tr>
                        <td>#<?= $m['id_anggota'] ?></td>
                        <td class="fw-bold"><?= $m['nama'] ?></td>
                        <td>
                            <div class="small"><i class="fas fa-envelope me-1"></i> <?= $m['email'] ?></div>
                            <div class="small"><i class="fas fa-phone me-1"></i> <?= $m['telepon'] ?></div>
                        </td>
                        <td class="text-muted"><?= $m['alamat'] ?></td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-outline-warning btn-edit" 
                                data-id="<?= $m['id_anggota'] ?>"
                                data-nama="<?= $m['nama'] ?>"
                                data-email="<?= $m['email'] ?>"
                                data-telepon="<?= $m['telepon'] ?>"
                                data-alamat="<?= $m['alamat'] ?>"
                                data-bs-toggle="modal" data-bs-target="#editMemberModal">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="<?= base_url('petugas/delete-member/'.$m['id_anggota']) ?>" 
                               class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus anggota ini?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="addMemberModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= base_url('petugas/save-member') ?>" method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Registrasi Anggota Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nomor Telepon</label>
                    <input type="text" name="telepon" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="3" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary w-100">Daftarkan Anggota</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="editMemberModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= base_url('petugas/update-member') ?>" method="POST" class="modal-content">
            <input type="hidden" name="id_anggota" id="edit_id">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title">Update Data Anggota</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama" id="edit_nama" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nomor Telepon</label>
                    <input type="text" name="telepon" id="edit_telepon" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" id="edit_alamat" class="form-control" rows="3" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-warning w-100 text-dark fw-bold">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $('.btn-edit').on('click', function() {
        $('#edit_id').val($(this).data('id'));
        $('#edit_nama').val($(this).data('nama'));
        $('#edit_email').val($(this).data('email'));
        $('#edit_telepon').val($(this).data('telepon'));
        $('#edit_alamat').val($(this).data('alamat'));
    });
</script>
</body>
</html>