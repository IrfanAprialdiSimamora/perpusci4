<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Petugas</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Perpustakaan</a>
        <div class="ms-auto">
            <span class="text-white me-3">
                👤 <?= session()->get('username') ?>
            </span>
            <a href="<?= base_url('logout') ?>" class="btn btn-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<!-- Content -->
<div class="container mt-5">
    <div class="text-center mb-4">
        <h2>Dashboard Petugas</h2>
        <p class="text-muted">Kelola data perpustakaan dengan mudah</p>
    </div>

    <div class="row g-4">

        <!-- Manage Books -->
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-body text-center">
                    <h5 class="card-title">📚 Data Buku</h5>
                    <p class="card-text">Kelola data buku perpustakaan</p>
                    <a href="<?= base_url('petugas/manage-books') ?>" class="btn btn-primary">
                        Kelola Buku
                    </a>
                </div>
            </div>
        </div>

        <!-- Manage Borrowing -->
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-body text-center">
                    <h5 class="card-title">📖 Peminjaman</h5>
                    <p class="card-text">Kelola peminjaman dan pengembalian</p>
                    <a href="<?= base_url('petugas/manage-borrowing') ?>" class="btn btn-success">
                        Kelola Peminjaman
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-body text-center">
                    <h5 class="card-title">📖 Members</h5>
                    <p class="card-text">Kelola Data Members</p>
                    <a href="<?= base_url('petugas/manage-members') ?>" class="btn btn-success">
                        Kelola Data Members
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Footer -->
<footer class="text-center mt-5 mb-3 text-muted">
    <small>© <?= date('Y') ?> Perpustakaan Digital</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>