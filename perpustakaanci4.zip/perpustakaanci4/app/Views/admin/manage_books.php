<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
</head>
<body>
    <h1>Manage Books</h1>
    <a href="<?= base_url('admin/add-book') ?>">Add New Book</a>
    <table>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Action</th>
        </tr>
        <?php foreach ($books as $book): ?>
            <tr>
                <td><?= $book['judul'] ?></td>
                <td><?= $book['penerbit'] ?></td>
                <td><a href="<?= base_url('admin/edit-book/'.$book['id_buku']) ?>">Edit</a> | <a href="<?= base_url('admin/delete-book/'.$book['id_buku']) ?>">Delete</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <a href="<?= base_url('admin/dashboard') ?>">Back to Dashboard</a>
</body>
</html>
