<?php

namespace App\Controllers;

use App\Models\BorrowingModel;
use CodeIgniter\Controller;

class PeminjamanController extends Controller
{
    public function index()
{
    $model = new BorrowingModel();
    $data['peminjaman'] = $model->findAll();

    var_dump($data['peminjaman']); die(); // Debugging
    return view('peminjaman/index', $data);
}


    public function tambah()
    {
        return view('peminjaman/tambah');
    }

    public function simpan()
{
    $model = new BorrowingModel();

    $data = [
        'id_anggota' => $this->request->getPost('id_anggota'),
        'id_buku' => $this->request->getPost('id_buku'),
        'tanggal_pinjam' => $this->request->getPost('tanggal_pinjam'),
        'tanggal_kembali' => $this->request->getPost('tanggal_kembali'),
        'status' => $this->request->getPost('status'),
    ];

    if ($model->insert($data)) {
        return redirect()->to('/peminjaman')->with('success', 'Peminjaman berhasil ditambahkan');
    } else {
        return redirect()->to('/peminjaman/tambah')->with('error', 'Gagal menambahkan peminjaman');
    }
}

}
