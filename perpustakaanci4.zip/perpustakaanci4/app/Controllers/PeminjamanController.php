<?php

namespace App\Controllers;

use App\Models\BorrowingModel;
use CodeIgniter\Controller;

class PeminjamanController extends Controller
{
    public function index()
{
    $model = new BorrowingModel();
    $data['peminjaman'] = $model->findAll();

    return view('peminjaman/index', $data); // Pastikan nama view benar
}


    public function tambah()
    {
        return view('peminjaman/tambah');
    }

    public function simpan()
    {
        $model = new BorrowingModel();

        $data = [
            'id_anggota' => $this->request->getPost('id_anggota'),
            'id_buku' => $this->request->getPost('id_buku'),
            'tanggal_pinjam' => $this->request->getPost('tanggal_pinjam'),
            'tanggal_kembali' => $this->request->getPost('tanggal_kembali'),
            'status' => $this->request->getPost('status'),
        ];

        $model->insert($data);
        return redirect()->to('/peminjaman');
    }
}
