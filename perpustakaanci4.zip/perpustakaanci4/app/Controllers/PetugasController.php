<?php

namespace App\Controllers;

use App\Models\BookModel;
use App\Models\BorrowingModel;
use CodeIgniter\Controller;

class PetugasController extends Controller
{
    public function __construct()
    {
        helper(['url', 'session']);
    }

    public function index()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'petugas') {
            return redirect()->to('/login');
        }
        return view('petugas/dashboard');
    }

    public function manageBooks()
    {
        $bookModel = new BookModel();
        $data['books'] = $bookModel->findAll();

        return view('petugas/manage_books', $data);
    }

   public function dataPeminjaman()
{
    $db = \Config\Database::connect();

    // ambil data peminjaman + join
    $builder = $db->table('peminjaman');
    $builder->select('
        peminjaman.*,
        buku.judul as judul_buku,
        anggota.nama as nama_anggota
    ');
    $builder->join('buku', 'buku.id_buku = peminjaman.id_buku');
    $builder->join('anggota', 'anggota.id_anggota = peminjaman.id_anggota');

    $data['peminjaman'] = $builder->get()->getResultArray();

    // 🔥 TAMBAHAN PENTING
    $data['books'] = $db->table('buku')->get()->getResultArray();
    $data['members'] = $db->table('anggota')->get()->getResultArray();

    return view('petugas/manage_borrowing', $data);
}
    public function saveBook()
{
    $model = new \App\Models\BookModel();

    $data = [
        'isbn' => $this->request->getPost('isbn'),
        'judul' => $this->request->getPost('judul'),
        'penulis' => $this->request->getPost('penulis'),
        'penerbit' => $this->request->getPost('penerbit'),
        'tahun_terbit' => $this->request->getPost('tahun_terbit'),
        'jumlah' => $this->request->getPost('jumlah'),
    ];

    $model->insert($data);

    return redirect()->to('/petugas/manage-books')
        ->with('success', 'Buku berhasil ditambahkan');
}
public function updateBook()
{
    $model = new \App\Models\BookModel();

    $id = $this->request->getPost('id_buku');

    $data = [
        'isbn' => $this->request->getPost('isbn'),
        'judul' => $this->request->getPost('judul'),
        'penulis' => $this->request->getPost('penulis'),
        'penerbit' => $this->request->getPost('penerbit'),
        'tahun_terbit' => $this->request->getPost('tahun_terbit'),
        'jumlah' => $this->request->getPost('jumlah'),
    ];

    $model->update($id, $data);

    return redirect()->to('/petugas/manage-books')->with('success', 'Data berhasil diupdate');
}
public function deleteBook($id)
{
    $model = new \App\Models\BookModel();
    $model->delete($id);

    return redirect()->to('/petugas/manage-books')
        ->with('success', 'Data berhasil dihapus');
}
public function dataPengembalian()
{
    $db = \Config\Database::connect();

    $builder = $db->table('pengembalian');
    $builder->select('
        pengembalian.*,
        peminjaman.id_buku,
        peminjaman.id_anggota,
        buku.judul as judul_buku,
        anggota.nama as nama_anggota
    ');
    $builder->join('peminjaman', 'peminjaman.id_peminjaman = pengembalian.id_peminjaman');
    $builder->join('buku', 'buku.id_buku = peminjaman.id_buku');
    $builder->join('anggota', 'anggota.id_anggota = peminjaman.id_anggota');

    $data['pengembalian'] = $builder->get()->getResultArray();

    return view('petugas/manage_pengembalian', $data);
}
public function saveBorrow()
{
    $db = \Config\Database::connect();
    $model = new \App\Models\BorrowingModel();

    $id_buku = $this->request->getPost('id_buku');

    // ambil data buku
    $buku = $db->table('buku')->where('id_buku', $id_buku)->get()->getRowArray();

    if ($buku['jumlah'] <= 0) {
        return redirect()->back()->with('error', 'Stok buku habis!');
    }

    // simpan peminjaman
    $model->insert([
        'id_buku' => $id_buku,
        'id_anggota' => $this->request->getPost('id_anggota'),
        'tanggal_pinjam' => $this->request->getPost('tanggal_pinjam'),
        'tanggal_kembali' => $this->request->getPost('tanggal_kembali'),
        'status' => 'dipinjam',
    ]);

    // kurangi stok
    $db->table('buku')->where('id_buku', $id_buku)
        ->update(['jumlah' => $buku['jumlah'] - 1]);

    return redirect()->to('/petugas/manage-borrowing')
        ->with('success', 'Peminjaman berhasil');
}
public function returnBook($id)
{
    $db = \Config\Database::connect();

    // ambil data peminjaman
    $pinjam = $db->table('peminjaman')
        ->where('id_peminjaman', $id)
        ->get()->getRowArray();

    // update status
    $db->table('peminjaman')
        ->where('id_peminjaman', $id)
        ->update(['status' => 'dikembalikan']);

    // tambah stok buku
    $db->table('buku')
        ->where('id_buku', $pinjam['id_buku'])
        ->set('jumlah', 'jumlah+1', false)
        ->update();

    // simpan ke tabel pengembalian
    $db->table('pengembalian')->insert([
        'id_peminjaman' => $id,
        'tanggal_pengembalian' => date('Y-m-d'),
        'denda' => 0 // nanti bisa dikembangkan
    ]);

    return redirect()->to('/petugas/manage-borrowing')
        ->with('success', 'Buku berhasil dikembalikan');
}
public function updateBorrow()
{
    $model = new \App\Models\BorrowingModel();

    $model->update($this->request->getPost('id'), [
        'tanggal_kembali' => $this->request->getPost('tanggal_kembali'),
        'status' => $this->request->getPost('status')
    ]);

    return redirect()->to('/petugas/manage-borrowing')
        ->with('success', 'Data berhasil diupdate');
}
public function deleteBorrow($id)
{
    $db = \Config\Database::connect();

    $pinjam = $db->table('peminjaman')
        ->where('id_peminjaman', $id)
        ->get()->getRowArray();

    // kalau belum dikembalikan → balikin stok
    if ($pinjam['status'] == 'dipinjam') {
        $db->table('buku')
            ->where('id_buku', $pinjam['id_buku'])
            ->set('jumlah', 'jumlah+1', false)
            ->update();
    }

    $db->table('peminjaman')->delete(['id_peminjaman' => $id]);

    return redirect()->to('/petugas/manage-borrowing')
        ->with('success', 'Data berhasil dihapus');
}
// Menampilkan daftar anggota
public function manageMembers()
{
    $db = \Config\Database::connect();
    $data['members'] = $db->table('anggota')->get()->getResultArray();
    return view('petugas/manage_members', $data);
}

// Simpan Anggota Baru
public function saveMember()
{
    $db = \Config\Database::connect();
    $data = [
        'nama'    => $this->request->getPost('nama'),
        'email'   => $this->request->getPost('email'),
        'telepon' => $this->request->getPost('telepon'),
        'alamat'  => $this->request->getPost('alamat'),
    ];
    $db->table('anggota')->insert($data);
    return redirect()->back()->with('success', 'Anggota berhasil didaftarkan');
}

// Update Data Anggota
public function updateMember()
{
    $db = \Config\Database::connect();
    $id = $this->request->getPost('id_anggota');
    $data = [
        'nama'    => $this->request->getPost('nama'),
        'email'   => $this->request->getPost('email'),
        'telepon' => $this->request->getPost('telepon'),
        'alamat'  => $this->request->getPost('alamat'),
    ];
    $db->table('anggota')->where('id_anggota', $id)->update($data);
    return redirect()->back()->with('success', 'Data anggota berhasil diperbarui');
}

// Hapus Anggota
public function deleteMember($id)
{
    $db = \Config\Database::connect();
    $db->table('anggota')->delete(['id_anggota' => $id]);
    return redirect()->back()->with('success', 'Anggota berhasil dihapus');
}

}
