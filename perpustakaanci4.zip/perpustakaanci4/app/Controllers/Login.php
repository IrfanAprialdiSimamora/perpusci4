<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Login extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function auth()
    {
        $session = session();
        $model = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Cari user berdasarkan username
        $user = $model->where('username', $username)->first();

        if (!$user) {
            $session->setFlashdata('error', '❌ Username tidak ditemukan!');
            return redirect()->to('/login');
        }

        // Cek password (tanpa enkripsi)
        if ($password != $user['password']) {
            $session->setFlashdata('error', '❌ Password salah!');
            return redirect()->to('/login');
        }

        // Set session jika login berhasil
        $session->set([
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role'],
            'logged_in' => true
        ]);

        // Redirect sesuai role
        if ($user['role'] == 'admin') {
            return redirect()->to('/admin/dashboard');
        } elseif ($user['role'] == 'petugas') {
            return redirect()->to('/petugas/dashboard');
        }

        // Jika role tidak dikenal
        $session->setFlashdata('error', '❌ Role tidak valid!');
        return redirect()->to('/login');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
