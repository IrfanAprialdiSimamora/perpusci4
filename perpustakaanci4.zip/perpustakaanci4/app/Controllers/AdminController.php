<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\BookModel;
use App\Models\BorrowingModel;
use CodeIgniter\Controller;

class AdminController extends Controller
{
    public function __construct()
    {
        helper(['url', 'session']);
    }

    public function index()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }
        return view('admin/dashboard');
    }

    public function manageUsers()
    {
        $userModel = new UserModel();
        $data['users'] = $userModel->findAll();

        return view('admin/manage_users', $data);
    }

    public function manageBooks()
    {
        $bookModel = new BookModel();
        $data['books'] = $bookModel->findAll();

        return view('admin/manage_books', $data);
    }

    public function manageBorrowing()
    {
        $borrowingModel = new BorrowingModel();
        $data['borrowings'] = $borrowingModel->findAll();

        var_dump($data['borrowings']); die(); // Debugging apakah data ada

        return view('admin/manage_borrowing', $data);
    }
}
