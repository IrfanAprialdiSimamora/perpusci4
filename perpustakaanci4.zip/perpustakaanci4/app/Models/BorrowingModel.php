<?php

namespace App\Models;

use CodeIgniter\Model;

class BorrowingModel extends Model
{
    protected $table = 'peminjaman'; // Harus sesuai dengan nama tabel di database
    protected $primaryKey = 'id_peminjaman';
    protected $allowedFields = ['id_anggota', 'id_buku', 'tanggal_pinjam', 'tanggal_kembali', 'status', 'created_at'];
}
